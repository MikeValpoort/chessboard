var c = document.getElementById("chessboard");
var ctx = c.getContext("2d");
ctx.moveTo(0,0);
ctx.lineTo(200,100);
ctx.stroke();

// size gebruiken we als een soort van id om het anwoord wat een string is ometezetten naar een getaal//
let i = prompt ("voer groote van boord in");

size = parseInt(i);
//de || vergelijk het in als 1 goed is dan werk het en NaN is de chijfer 
if (isNaN(size) || size <2){
console.log("groter getaal dan 2");
}

// else voor de console log
else {
    for (let row = 0; row < size; row++) {
        let rowString = '';  //row is nu 0 dus de gebruiker yped iets in en als het hoger is dan row=0 dan doet hij er een bij//
        for (let col = 0; col < size; col++) {
            if ((row + col) % 2 === 0) {
                rowString += '#';//
            } else {
                rowString += ' ';
            }
        }
        console.log(rowString);
    }
}

















//for loop//
//for (let i = 100; i > 0; i--){
  //  console.log(i);
//}

//while loop//

//let e = 100;
//while (e > 5) {
   // console.log(e);
   // e--;
//}
